import 'package:flutter/material.dart';

class HEllos extends StatefulWidget {
  const HEllos({super.key});

  @override
  State<HEllos> createState() => _HEllosState();
}

class _HEllosState extends State<HEllos> {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: [
              MaterialButton(
                onPressed: () {
                  Navigator.pushNamed(context, "/second");
                },
                color: Colors.green,
                textColor: Colors.red,
                child: const Text("Material Button"),
              ),
              ElevatedButton(
                onPressed: () {
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(builder: (context) => const HelloScreen()),
                  // );
                },
                child: const Text("HEllo  Elevated Button"),
                style: const ButtonStyle(),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.add),
                label: const Text("Hello"),
              ),
              const SizedBox(
                height: 50,
              ),
              FloatingActionButton(
                onPressed: () {},
                child: const Icon(Icons.add),
                backgroundColor: Colors.red,
                foregroundColor: Colors.amber,
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.abc),
                iconSize: 50,
              ),
              TextButton(
                onPressed: () {},
                child: const Text("Text Button"),
              ),
            ],
          ),
        ),
      );
  }
}